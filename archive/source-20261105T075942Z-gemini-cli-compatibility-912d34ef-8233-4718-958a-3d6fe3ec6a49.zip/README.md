# Agent Profile and Skills

Canonical source for Tobi's portable agent profile and 30 curated skills.
The profile defines operating posture; skills teach task methods with reasons,
worked examples and conditional dependencies. Installed copies are deployments,
not additional sources to edit.

## Start here

- Read [profile/base.md](profile/base.md) for the portable global profile.
- Use [SKILLS.md](SKILLS.md) to find a skill, its owner and provenance.
- Read [AGENTS.md](AGENTS.md) before maintaining this repository.
- To install a revision, follow [distribution](#distribution-and-verification)
  and verify the target host separately.

```text
profile/base.md          Portable global agent instructions
profile/global/          Exact environment/client installation bindings
archive/                 Committed previous profiles and complete package snapshots
skills/engineering/      Eleven engineering methods
skills/general/          Nineteen general methods
client-config/           Native client configuration fragments and agent roles
scripts/sync_clients.py  One local distribution entrypoint; no scheduler
SKILLS.md                Included inventory and external catalog entries
```

Each skill directory is a complete package: instructions, metadata and any
needed references, scripts, assets, licenses and notices. System and plugin
skills remain host-managed. Project-owned methods such as Judgment are linked
in the [external inventory](SKILLS.md#project-owned-skills).

## How the methods fit together

| Concern | Owner |
|---|---|
| Domain language, naming and relationships | Domain Modeling |
| Capability boundaries and module structure | Vertical Slices |
| Architecture, data, configuration, security, recovery and delivery decisions | Engineering Practices |
| Current research for a consequential decision | State of the Art |
| Deliberate architectural reassessment | Improve Codebase Architecture |
| Bounded delegation, ownership and useful returns | Puppeteer |
| Iterative specialist challenge through the lead agent | Grilling with Agents |
| Substantial work, versioned plans and remote issues/PRs | Road to Glory |
| Independent implementation, UI and documentation review | Engineering Review |

Road to Glory separates implementation review from the subsequent documentation
update and review. It cleans up completed work only after both pass. Small,
well-understood tasks remain direct work. Conditional dependencies use the
available method and return to their caller without restarting an active workflow.

Grilling interviews the user when chosen. Grilling with Agents keeps all questions
between specialists and the lead, whether selected directly or used by a workflow.
It returns decisions, reasons and unresolved prerequisites without user questions.
An active Road to Glory plan owns that result, including its evidence and rejected
alternatives; a direct bounded assessment can return only a report.

Good Writing selects a writing method from the reader and purpose:

| Writing concern | Owner |
|---|---|
| Scout and select source material before drafting | Writing Fragments |
| Customer and business-partner correspondence | Customer Writing |
| Sales copy, offers and commercial decisions | Commercial Writing |
| Shared working knowledge in Pages and Spaces | Workspace Writing |
| Repository README, agent instructions, code-owned SDK docs and ordered system books | Engineering Documentation |
| Standalone technical manuals, procedures and reference material | Technical Writing |
| Wording and final prose check | Unslop |
| Explanatory figures | Editorial SVG Diagrams |

Good Writing prepares a purpose-scaled source handoff through Writing Fragments
before selecting the writer. Direct specialists reuse that handoff or prepare it
when missing. Preserve evidence, context and uncertainty; consider figures when
they explain more clearly. Small revisions need only a small local selection.
Specialists also work directly and do not route back to Good Writing. Use Unslop
throughout the writing routes when available, including after artifact assembly.
Editorial SVG Diagrams explains concepts, relationships and behavior. SVG Design
owns logos, icons, brand assets and decorative website graphics. The purpose of
the graphic determines the method; both may contribute to one website.

Engineering Documentation keeps README orientation, repository agent instructions
and deeper docs together, with distinct responsibilities and one owner per fact.
It retains Synopsis's numbered chapters and substantial topic folders when a book
is useful. Figures carry relationships and behavior; remove the prose they replace
and retain compact text equivalents, exact commands and necessary conditions.
Technical Writing covers standalone manuals without assuming codebase access.
Both routes use Unslop and Editorial SVG Diagrams when available.

## Invocation and host boundaries

Descriptions explain tasks, outcomes and relevant boundaries. Native invocation
policy belongs in `agents/openai.yaml`. Allowing implicit invocation permits
matching selection; it does not mean a skill runs on every turn.

Grilling, Grilling with Agents, Improve Codebase Architecture and MinMax Codebase
disable implicit invocation. The five writing specialists and Writing Fragments
also remain explicit entries; Good Writing reads Writing Fragments for preparation
and its selected specialist for composition. An authorized workflow may deliberately read a scoped method
when the host permits composition. A reference grants no additional authority to
implement, publish or override the host.

Installed files, catalog discovery, loaded metadata and observed model behavior
are separate checks. A native policy does not prove a model followed it or hide
the skill from every catalog UI. Missing tools or skills must remain visible;
reading instructions alone does not establish their application.

## Profiles and exact environment selection

The baseline in `profile/base.md` contains no host identifiers or method routing.
Environment identity belongs in the source path and adjacent `binding.json`:

```text
profile/global/<os>/<hostname>/<login>/<client>/<context>/binding.json
```

The four bindings currently registered for this Mac select the common baseline.
A binding names the native configuration root relative to the observed user's
home, the native profile filename, and the content to install. For example:

```json
{
  "configuration_root": { "relative_to": "user_home", "path": ".codex" },
  "target_filename": "AGENTS.md",
  "content": { "base": "profile/base.md" }
}
```

A binding may add a `local` Markdown component relative to its own directory;
resolve conflicting instructions at their owner before composing one payload.
Source composition does not change the client's instruction hierarchy. Standalone
purpose instructions need not inherit the baseline. Keep identity out of installed
instruction text; this is identification, not cryptographic signing.

The updater observes OS, hostname, effective login, home and native client root.
On macOS the hostname means `scutil --get LocalHostName`, not a DNS alias or display
name. Only one exact binding may match. Missing, renamed, ambiguous or unsupported
identity means no update. There is no local environment-to-source table, fuzzy
match, wildcard, or automatic baseline fallback. A context label alone is not
proof of an account or active configuration root.

Two machines with the same login need distinguishable observable host identities.
Cloned identical selectors cannot identify different machines. Multiple client
homes need distinct verified bindings; switching accounts inside one shared
client home does not create separate global profiles. Cloud environments need
their own supported identity and installation mechanism. Never infer cloud identity
from a local checkout or login.

Important instructions outside repositories may be kept under
`profile/directories/<os>/<hostname>/<login>/<client>/<purpose>/`; reusable
standalone instructions under `profile/purposes/<purpose>/`. These are separate
scopes, not automatic global-sync targets. Ordinary repository `AGENTS.md` files
and VPS roles already maintained elsewhere remain with their existing owners.
Use ordinary source Markdown names so they are not accidentally loaded as active
instructions. Share only deliberate identifiers and instructions; keep credentials
and private runtime configuration out of Git.

## Distribution and verification

Use `scripts/sync_clients.py` as the single local reconciliation entrypoint. It
currently supports the four registered macOS clients, one `default` context per
client, and needs Python and PyYAML. Multiple contexts, other operating systems
and profile scopes require their own verified selection or installation adapter.
Audit first; review initial ownership and local differences
before explicitly enrolling existing installations:

```sh
python3 scripts/sync_clients.py
python3 scripts/sync_clients.py --apply --adopt-existing
```

After enrollment, use `--apply` without adoption. Drift against the last receipt
is a conflict to inspect, not permission to overwrite. Adoption is a deliberate
migration option, never the unattended default. The helper selects exact profile
bindings, discovers packages only from `skills/engineering/*/SKILL.md` and
`skills/general/*/SKILL.md`, and reconciles complete packages. `SKILLS.md` links
and unrelated folders confer no deletion authority.

| Client | Native profile | Common skill root | Invocation adaptation |
|---|---|---|---|
| Codex | `~/.codex/AGENTS.md` | `~/.codex/skills/` | Retain `agents/openai.yaml`. |
| Claude Code | `~/.claude/CLAUDE.md` | `~/.claude/skills/` | Render explicit-only policy as native `disable-model-invocation: true`. |
| Kimi Code | `~/.kimi-code/AGENTS.md` | `~/.kimi-code/skills/` | Render the supported native frontmatter equivalent. |
| Gemini CLI | `~/.gemini/GEMINI.md` | `~/.gemini/skills/` | Verify the installed loader; 0.24.5 has no equivalent explicit-only policy. |

The paths above are the registered defaults, not substitutes for checking the
effective native root. Preserve client configuration, local disabling and stricter
native flags. Claude/Kimi overlays are intentional deployment differences; the
shared source stays unchanged. Gemini's disabled list remains authoritative for
its own availability. File equality on Gemini does not establish the ten shared
explicit-only policies. Do not silently enable, disable or upgrade clients to hide
that limitation. Recheck native compatibility when client versions change.

### Archive before every exchange

**Before replacing or removing a managed profile or skill package, preserve its
complete old bytes in this repository and commit that recovery point. This rule
applies equally to manual and automatic source edits and installation updates.**
An old Git commit or a backup outside the repository alone is insufficient.

Use a uniquely named `archive/<UTC timestamp>-<reason>.md` for a single profile,
or a ZIP with a manifest for complete package/client snapshots. Include old files
that the new package removes, source/target provenance and hashes. Never overwrite
an archive. Keep nested native instruction filenames inside the ZIP. If private
content cannot be archived safely in Git, stop that replacement and report the
specific conflict; do not expose the content or skip its recovery requirement.
A failed archive or commit must leave the installation unchanged.

For source updates, inspect branch, remote, working tree and the proposed revision
first. Do not merge over ongoing local skill work. A fast-forward must retain a
committed archive of displaced released content; if the incoming history lacks
that recovery point, stop the automatic source update and prepare it through a
reviewed source change. The helper consumes the checked-out committed revision;
it does not run a second pull loop.

### Reconcile and prove the result

1. Inspect source inventory, effective bindings, prior receipts, local differences
   and name collisions. Preserve unrelated/system/plugin/project-owned packages,
   including Judgment. Review first enrollment; never adopt by name alone.
2. Archive and commit the complete old affected content, then replace whole managed
   packages so retired internal files disappear. Remove a whole package only if a
   previous receipt proves this collection owned it and it is absent from current
   source. Unexplained local changes block that package's replacement/removal.
3. Compare relative file lists and hashes against the intended native adaptation.
   Check metadata separately, then use each installed client's native loader/menu
   to verify actual discovery. Do not confuse enabled status with implicit invocation.
   Keep unsupported capabilities and existing diagnostics visible.
4. Keep per-client source revision, target, installed hashes and adaptations in
   deployment receipts outside instruction text. A receipt records installation,
   not proof of loader acceptance or model behavior. Preserve unrelated settings.
5. For rollback, archive the current state first, restore the selected complete
   snapshot and verify the actual target again. Keep any subsequent local changes.

Local deployment receipts live in
`~/Library/Application Support/Agent Profile/deployments/<client>-default.json`.
The committed archive manifest records the previous content; these receipts
record the installed result. An interrupted run can leave some replacements
ahead of its receipt. The next audit stops on that drift: inspect the committed
archive and current files before repairing the receipt or completing the update.
Do not use initial adoption to bypass a later conflict.

The existing Alice task owns scheduling. Do not create another timer or independent
copy path. An unavailable Mac, checkout or required runtime is skipped for that
run and retried at the next scheduled run; do not create substitute environments
or infer that a local path is accessible in Cloud. Alice's personal ChatGPT skill
checkout remains a separate supported deployment owner, not a local client root.

Native documentation: [Codex skills](https://developers.openai.com/codex/skills),
[Codex profiles](https://developers.openai.com/codex/guides/agents-md),
[Claude skills](https://code.claude.com/docs/en/skills),
[Kimi skills](https://moonshotai.github.io/kimi-code/en/customization/skills),
[Gemini skills](https://geminicli.com/docs/cli/using-agent-skills/).
Verify installed-version behavior rather than assuming newer documentation applies.

A copy does not install tools, MCP servers, plugins or account access. Editorial
SVG's PNG/PDF export needs Python with CairoSVG or an available Inkscape CLI.
The Pages plugin owns native page actions; writing instructions do not authorize
changes to existing pages.

Each included skill has SVG icons for compact and larger displays in its
`assets/` directory, referenced by native interface metadata. The writing family
reuses its original shared pencil. The other marks use restrained colors and a
fine neutral edge for light and dark surfaces. Keep both sizes with the complete
package and check them at their actual display sizes.

Cloud imports and return exports can normalize YAML or add interface metadata.
Compare metadata semantically as well as checking file hashes, and verify each
host's supported schema. The writing packages retain supported product metadata;
`api` is excluded because the inspected Codex loaders rejected the entire metadata
file when it appeared. A host-generated product-list difference belongs in export
evidence, not an unchecked copy into Codex. See the compatibility provenance in
[SKILLS.md](SKILLS.md#writing-sources-and-composition).

## Optional client configuration

[client-config](client-config) contains merge fragments, not replacement user
configurations. Back up the live file, merge only the intended keys, parse it and
inspect the effective setting when the client exposes one. Main-model choices,
authentication and private provider settings are outside these fragments.

| Client | Fragment | Scope |
|---|---|---|
| Codex | [codex.toml](client-config/codex.toml) | Tool-output limit and overridable subagent defaults; not a whole-task token budget. |
| Claude Code | [claude.json](client-config/claude.json) | Child-delegation depth in supported versions; not a total agent-call cap. |
| Kimi Code | [kimi.toml](client-config/kimi.toml) | Selectable secondary-model pool; no forced main model or concurrency cap. |

The narrow [Codex roles](client-config/codex-agents) belong in `~/.codex/agents/`;
the optional [Claude roles](client-config/claude-agents) in `~/.claude/agents/`.
Verify actual permissions when delegating; live host overrides can affect them.
No role is assigned to every task. Gemini has no configuration fragment here.

MinMax Tokens owns information economy; Puppeteer owns delegation, phase/capability
model selection and verified integration. Its shared
[model-routing reference](skills/general/puppeteer/references/model-routing.md)
records dated preferences and host limitations for planning, implementation,
independent review and visual work. Apply routing by default when assigning work;
it does not switch the main model or modify client settings. Revalidate the affected
entries when model lines, native routing or observed task performance change, and
refresh that single owner during authorized maintenance using the archive and
distribution procedure above. Assess available total token use together with
correction cycles and achieved quality; keep task observations at the existing
work owner and feed recurring lessons back into routing. No separate scheduler
or usage tracker is introduced.

Its [worked examples](skills/general/puppeteer/SKILL.md#a-scout-and-a-useful-return)
show useful task splits; the optional [evidence note](skills/general/puppeteer/references/evidence.md)
explains research limits. Configured limits and prompt methods do not guarantee
savings. Recover truncated evidence through targeted reads and preserve required
verification.

## Source history

The portable profile and former Engineering repository share this Git history.
The Engineering history ends at source commit
`18a5e35e039c977247ee7f8dea400e1ca95c50ed` before consolidation. The former local
repository is a retirement record, not an active source. Profile releases in
[archive](archive) preserve exact rollback bytes. Skill licenses, notices and
manifests retain their own provenance; runtime backups stay outside Git and
active skill roots.
