# Skill architecture: types, trees and dependencies

Read this when you create a skill, place it in a collection, add a router, or
review how skills load each other. It owns the type system and the edge rules;
`SKILL.md` keeps only the summary.

- [Why a tree](#why-a-tree)
- [The six types](#the-six-types)
- [Edge rules](#edge-rules)
- [Roles in domains and flows](#roles-in-domains-and-flows)
- [Declare type and dependencies](#declare-type-and-dependencies)
- [Place a new skill](#place-a-new-skill)

## Why a tree

Picture a room. The agent stands in the middle. Around it stand **core skills**
it can use anywhere, and several **trees**, one per domain: writing, software
engineering, design. Each tree has a root that decides where in the tree the
work belongs, inner nodes that compose or order methods, and leaves that do one
job well.

This shape exists for three reasons:

- **Routing saves context.** Only the roots compete for selection. A request
  loads one root and then only the branches it needs, instead of every skill
  whose description sounds related.
- **Flows define order and roles.** Multi-step work, especially with several
  agents, needs one place that says what happens in which order and who does it.
  The orchestrating agent follows the flow; delegates take single branches.
- **Leaves stay reusable.** A method that loads nothing and assumes no caller
  can be used by any router, by a flow, or by a user who names it directly.

A mesh, where skills call each other freely, loses all three: loads become
unpredictable, cycles make agents restart workflows, and no skill can change
without checking every other one.

## The six types

| Type | What it is | Selection | Loads |
|---|---|---|---|
| **Core** | A standalone method on the agent's surface, useful in any context | Implicit | Nothing |
| **Domain** | The root of a tree: establishes the context and routes into it | Implicit | Its children — one, several, or a role's pack |
| **Parent** | An inner node that groups children and applies them together | Explicit-only | Its children, without an order |
| **Core flow** | A sequence of steps and roles that stands on the surface | Implicit | Its step skills, left to right, in any tree |
| **Flow** | A sequence of steps and the roles that run them, inside a tree | Explicit-only, reached through its domain | Its step skills, left to right, in its tree |
| **Leaf** | A self-contained method, always invoked manually: by a routing skill or a person | Explicit-only | Nothing, ever |

Domain, parent, flow and core-flow skills are **routing skills**: nodes that have
children. Each skill has exactly one type, and the type fixes its selection:
`core`, `core-flow` and `domain` are implicit; `parent`, `flow` and `leaf` are
explicit-only. A tool can therefore check a skill's invocation policy against
its declared type.

**Selection decides the type.** A skill on the agent's surface — one the agent
may select by itself — is a core skill, a domain root, or a core flow. A skill
that is never selected implicitly is a leaf, or a parent or flow if it loads
other skills. There is no explicit-only core skill: a skill that only a person
calls by name, such as an interview started with "grill me", is a leaf whose
root is that person. Core and leaf both load nothing; a core skill decides for
itself when it applies, a leaf waits to be called.

**Core flow and flow share a shape, not a position.** Both run steps in order.
A core flow stands on the surface, implicit like a core skill; because it stands
in the middle, it may enter several trees, as the agent itself may. A flow lives
inside a tree, is explicit-only, is reached through its domain and never leaves
that tree. Only this one combination gets its own type: a core skill that loads
nothing is simply core, and a surface skill that roots a tree is a domain.

A method may stay core while no tree exists for its context yet. When you
create one, ask whether more skills of that kind will follow; if so, give it its
domain early instead of moving it later.

**Every leaf works alone.** A user can call a leaf by name, so it must not
depend on a caller's context, name a caller, or assume another method ran first.
It may state what input it needs.

**A flow orders, it does not own.** Each step skill in a flow stays usable
without the flow. The flow adds what no single step can: the order, the
hand-offs between steps, and conditions such as "use this flow only as the
orchestrating agent". Read a flow left to right; it does not reach further down
the tree than its own steps.

**Sub-domains are rare.** If a part of a domain needs its own selection, prefer
a parent skill. Introduce a nested domain only when that part is a context of
its own with several parents or flows beneath it.

## Edge rules

1. **Start in the middle.** Only core skills, core flows and domain roots are
   implicit. Every other skill is reached through a routing skill or by a person
   naming it; a person who calls a leaf by name is its root. Whatever stands in
   the middle may enter one tree or several.
2. **Edges point down.** A routing skill names its children; a child never names
   its caller. Results go back to whoever loaded the child.
3. **Never across trees.** If a skill in one tree needs work from another tree —
   a writing leaf that wants a diagram — it returns that need to the agent in
   the middle, which opens the other domain itself. A cross-tree edge means the
   trees are cut wrong, or the shared skill should be core.
4. **Branches do not reconnect.** When two siblings need the same child, the
   common parent loads it once for both. When only some siblings need it, add a
   parent for exactly those. When every tree needs it, it is core.
5. **Boundary mentions are allowed.** A description may say "logos belong to SVG
   Design" to prevent a wrong selection. That sentence routes nothing.

Example of rule 4: in an engineering domain, both the implementer and the
reviewer need the test-design leaf. Neither role's skills load it; the domain
lists it in both role rows, so it remains one edge from the common parent.

## Roles in domains and flows

A domain or flow may define **roles** instead of single targets: implementer,
reviewer, orchestrator, documenter. A role is a row that selects a **pack** —
the children that always apply in that role, plus conditional ones:

```markdown
| You are…      | Load always                            | Load when needed        |
|---------------|----------------------------------------|-------------------------|
| Implementer   | design-method, comment-method          | test-method             |
| Reviewer      | review-parent                          | its lenses              |
| Orchestrator  | delivery-flow                          | delegation-method       |
```

Packs can combine when an agent holds two roles at once. Mark combinations that
must not happen, for example "the orchestrator does not implement the work it
reviews". A delegate receives its role's pack by name in its brief, so it loads
the methods itself instead of receiving a paraphrase.

## Declare type and dependencies

The Agent Skills specification has no field for dependencies between skills;
its `metadata` field is a free map of string keys to string values, and
`compatibility` describes environment requirements such as tools or network
access. Use `metadata` for the machine-readable declaration:

```yaml
---
name: delivery-flow
description: …
metadata:
  skill-type: flow
  skill-tree: engineering
  skill-requires: review-parent delegation-method
---
```

- `skill-type` is exactly one of `core`, `core-flow`, `domain`, `parent`, `flow`,
  `leaf`.
- `skill-tree` names the domain a non-core skill belongs to.
- `skill-requires` lists, space-separated, the children without which a routing
  skill cannot do its job. Optional children appear only in the body. Leaves and
  core skills require nothing.

The agent learns the same facts after it has chosen the skill, from one line at
the top of the body:

```markdown
**Flow skill** in the engineering domain. Requires: review-parent, delegation-method.
If one is missing, stop, say this skill is incomplete without it, and do not run
a partial flow.
```

Keep both out of the `description`: the description decides selection, and a
dependency list there spends the selection budget on information that only
matters after the choice.

Humans see the type in the catalog through the short description, which starts
with it — `Leaf: Complete replacements and model corrections`, `Domain: Write
for the reader and purpose` — in `agents/openai.yaml` and
`metadata.short-description`.

**Check dependencies when installing, not while working.** The collection's
installation tooling should refuse to install a routing skill whose required
children are missing, and report edges that point up or across trees. The stop
line in the body is the fallback for hosts the tooling does not cover. To
distribute a tree as a whole, package it together, for example as one plugin.

## Place a new skill

1. **Should the agent select it by itself?** No: it is a leaf — or a parent or
   flow if it loads other skills — reached through a routing skill or by a
   person. Yes: continue.
2. **Does it load other skills?** No: core — useful in any context; if it only
   serves one context, it is a leaf of that tree, and the tree may need its
   domain first. Yes: `domain` if it roots a tree and routes into it; `core-flow`
   if it runs steps in order, possibly across trees.
3. **Inside a tree, does a node define ordered steps or roles?** Yes: flow.
   Otherwise, if it groups children it applies together: parent.
4. **Check the edges** against the rules above with the collection's graph
   audit, then declare the type and requirements in `metadata`, the first body
   line and the short description.
